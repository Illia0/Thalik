import {closet} from "./closet"


describe ('Closet testing',() =>{
    let mycloset:closet;
    beforeEach(()=>{
        mycloset = new closet("closet",10,10,10);
    }
    )
    it("Створення екземпляру класу", ()=>{
        expect(mycloset).toBeTruthy();
    })
    it("Розрахунок площини 10x10", ()=>{
        mycloset.find_S();
        let s = mycloset.S;
        let t = 10*10;
        expect(s.toFixed(2)).toBe(t.toFixed(2));
    })
    it("Розрахунок об'єму 10x10x10", ()=>{
        mycloset.find_V();
        let v = mycloset.V;
        let t = 10*10*10;
        expect(v.toFixed(2)).toBe(t.toFixed(2));
    })
    it("Розрахунок ціни", ()=>{
        mycloset.money();
        let money = mycloset.m;
        let v = mycloset.V;
        let t = 75*v;
        expect(money.toFixed(2)).toBe(t.toFixed(2));
    })
})