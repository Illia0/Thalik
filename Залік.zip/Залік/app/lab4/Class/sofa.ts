import {furniture} from "./furniture"

export class sofa extends furniture
{
    constructor(override naz:string, override h: number, public l:number, public w:number ){ super() }
    override find_S() {
        this.S = this.l * this.w
    }
    override find_V() {
        this.V = this.l * this.w * this.h
    }
    money(){
        this.find_S()
        this.m = this.S*this.S/3+5000
    }
}