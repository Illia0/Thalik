import {sofa} from "./sofa"


describe ('Sofa testing',() =>{
    let mysofa:sofa;
    beforeEach(()=>{
        mysofa = new sofa("sofa",10,10,10);
    }
    )
    it("Створення екземпляру класу", ()=>{
        expect(sofa).toBeTruthy();
    })
    it("Розрахунок площини 10x10", ()=>{
        mysofa.find_S();
        let s = mysofa.S;
        let t = 10*10;
        expect(s.toFixed(2)).toBe(t.toFixed(2));
    })
    it("Розрахунок об'єму 10x10x10", ()=>{
        mysofa.find_V();
        let v = mysofa.V;
        let t = 10*10*10;
        expect(v.toFixed(2)).toBe(t.toFixed(2));
    })
    it("Розрахунок ціни", ()=>{
        mysofa.money();
        let money = mysofa.m;
        let s = mysofa.S;
        let t = s*s/3+5000;
        expect(money.toFixed(2)).toBe(t.toFixed(2));
    })
})