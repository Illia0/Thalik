export abstract class furniture{
    naz!: string;
    h!:number;
    S!:number;
    V!:number;
    m!:number;
    constructor(){}
    show(){
        return "Назва=" + this.naz + " " + "Висота=" + this.h + " "  + "Площа=" + ""+  this.S + " " + "Об'єм=" + this.V + ' '+"Ціна=" + this.m
    }
    abstract find_S():any;
    abstract find_V():any;
    abstract money():any;
}