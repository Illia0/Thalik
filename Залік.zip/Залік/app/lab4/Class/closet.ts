import {furniture} from "./furniture"

export class closet extends furniture
{
    constructor(override naz:string, override h: number, public l:number, public w:number ){ super() }
    override find_S() {
        this.S = this.l * this.w
    }
    override find_V() {
        this.V = this.l * this.w * this.h
    }
    override money(){
        this.find_V()
        this.m = 75*this.V
    }
}