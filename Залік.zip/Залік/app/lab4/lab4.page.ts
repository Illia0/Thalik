import { Component, OnInit } from '@angular/core';
import {furniture} from "./Class/furniture"
import {closet} from "./Class/closet"
import {sofa} from "./Class/sofa"

@Component({
  selector: 'app-lab4',
  templateUrl: './lab4.page.html',
  styleUrls: ['./lab4.page.scss'],
})
export class Lab4Page implements OnInit {

  furnit: furniture[] = [];
  max:number = 0;
  constructor() { }
  getRandomInt(max:number){
    return Math.floor(Math.random()*Math.floor(max)+1)
  }

  ras (nn:any){
    this.furnit = new Array;
    let n = parseInt(nn)
    for(let i=0;i<n;i++){
      this.furnit.push(new closet("Шафа", this.getRandomInt(10), this.getRandomInt(10), this.getRandomInt(10)))
      this.furnit.push(new sofa("Диван", this.getRandomInt(10), this.getRandomInt(10), this.getRandomInt(10)))
    }
    this.max=0;
    this.furnit.forEach((element) => {
      element.find_S();
      element.find_V();
      element.money();
      if (this.max < element.m) this.max = element.m;
    })
  }
  getColor(el:number, max:number){
    return (Math.abs(el-max)<0.01)?"red":''
  }

  ngOnInit() {
  }

}
