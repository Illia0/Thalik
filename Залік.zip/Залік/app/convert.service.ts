import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConvertService {

  constructor() { }

  convertToBase(number: number, base: number): string {
    if (base < 2 || base > 16) {
      throw new Error('Invalid base. Base must be between 2 and 16.');
    }

    if (number === 0) {
      return '0';
    }

    let result = '';
    while (number > 0) {
      const remainder = number % base;
      result = this.getDigit(remainder) + result;
      number = Math.floor(number / base);
    }

    return result
  }
  private getDigit(value: number): string {
    if (value < 10) {
      return value.toString();
    } else {
      const offset = value - 10;
      return String.fromCharCode('A'.charCodeAt(0) + offset);
    }
  }
}
