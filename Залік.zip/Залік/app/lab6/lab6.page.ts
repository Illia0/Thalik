import { Component, OnInit } from '@angular/core';
import { exam } from "./class/exam"
import { test } from "./class/test"
import { final_exam } from "./class/final_exam"

@Component({
  selector: 'app-lab6',
  templateUrl: './lab6.page.html',
  styleUrls: ['./lab6.page.scss'],
})
export class Lab6Page implements OnInit {
  show:string[]= [];

  constructor() { }
  ngOnInit() {}
  ras(){
    let test1 = new test('test1', 'math');
    let exam1 = new exam('exam1', 'phis');
    let exam2 = new final_exam('exam2', 'math');
    this.show.push(test1.name + ' '+test1.item + ' '+test1.num +' '+ test1.score() + ' '+test1.pass());
    this.show.push(exam1.name + ' '+exam1.item + ' '+exam1.num_test +' '+ exam1.num_tasks + ' ' + exam1.score() + ' '+exam1.pass());
    this.show.push(exam2.name + ' '+exam2.item + ' '+exam2.num_test +' '+ exam2.num_tasks + ' '+ exam2.score() + ' '+exam2.pass());
  }
}
