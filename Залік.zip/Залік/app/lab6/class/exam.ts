import {tasks} from "../interface/tasks"
import {test} from "./test"

function getRandomInt(min:number, max:number) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}


export class exam extends test implements tasks {
    num_test = 6;
    num_tasks = 2;
    override score(){
        let rand1 = getRandomInt(0,10);
        let rand2 = getRandomInt(0,10);
        this.S = this.num_test*rand1 + this.num_tasks*2*rand2;
        return this.S
    }
    override pass(){
        if (this.S >= 60){
            return true;
        }
        else{
            return false;
        }
    }
}