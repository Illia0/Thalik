import {trial} from "../interface/trial"
import {questions} from "../interface/questions"

function getRandomInt(min:number, max:number) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}

export class test implements trial, questions{
    name = '';
    item = '';
    num = 10;
    S = -1;
    constructor (name: string, item:string){
        this.name = name;
        this.item = item;
    }
    score(){
        let rand = getRandomInt(0,10);
        this.S = this.num*rand
        return this.S;
    }
    pass(){
        if (this.S < 0){
            this.score();
        }
        if (this.S >= 60){
            return true;
        }
        else{
            return false;
        }
    }
}

