import {exam} from "./exam"

function getRandomInt(min:number, max:number) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}

export class final_exam extends exam {
    admission = true;
    override score(){
        if (this.admission==true){
            let rand1 = getRandomInt(0,10);
            let rand2 = getRandomInt(0,10);
            this.S = this.num_test*rand1 + this.num_tasks*2*rand2;
            return this.S;
        }
        else{
            return 0;
        }
    }
    override pass(){
        if (this.admission==true && this.S >= 60){
            return true;
        }
        else{
            return false;
        }
    }
}