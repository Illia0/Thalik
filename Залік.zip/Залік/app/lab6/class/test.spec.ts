import {test} from "./test"


describe ('MyTests testing',() =>{
    let test1:test;
    beforeEach(()=>{
        test1 = new test('test1', 'math');
    }
    )
    it("Створення екземпляру класу", ()=>{
        expect(test).toBeTruthy();
    })
    it("Розрахунок score", ()=>{
        test1.score();
        let s = test1.S;
        expect(s>=0);
    })
    it("Розрахунок результату", ()=>{
        let res = test1.pass();
        expect(res == (test1.S>=60));
    })
})