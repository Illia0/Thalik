import {exam} from "./exam"


describe ('Final_exams testing',() =>{
    let test1:exam;
    beforeEach(()=>{
        test1 = new exam('test1', 'math');
    }
    )
    it("Створення екземпляру класу", ()=>{
        expect(exam).toBeTruthy();
    })
    it("Розрахунок score", ()=>{
        test1.score();
        let s = test1.S;
        expect(s>=0);
    })
    it("Розрахунок результату", ()=>{
        let res = test1.pass();
        expect(res == (test1.S>=60));
    })
})