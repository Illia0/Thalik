import {final_exam} from "./final_exam"


describe ('Exams testing',() =>{
    let test1:final_exam;
    beforeEach(()=>{
        test1 = new final_exam('test1', 'math');
    }
    )
    it("Створення екземпляру класу", ()=>{
        expect(final_exam).toBeTruthy();
    })
    it("Розрахунок score", ()=>{
        test1.score();
        let s = test1.S;
        expect(s>=0);
    })
    it("Розрахунок результату", ()=>{
        let res = test1.pass();
        expect(res == (test1.S>=60));
    })
})