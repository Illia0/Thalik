export interface trial {
    pass():any;
}