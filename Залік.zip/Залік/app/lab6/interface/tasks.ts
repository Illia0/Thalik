export interface tasks {
    num:number;
    score():any;
}