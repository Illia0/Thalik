export interface questions {
    num:number;
    score():any;
}