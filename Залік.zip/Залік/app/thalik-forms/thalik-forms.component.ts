import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators,AbstractControl } from '@angular/forms'
import { ToastController } from '@ionic/angular';
import {ConvertService} from '../convert.service'

@Component({
  selector: 'app-thalik-forms',
  templateUrl: './thalik-forms.component.html',
  styleUrls: ['./thalik-forms.component.scss'],
})
export class ThalikFormsComponent implements OnInit {
  @Input() name: string="Форми"
  dynamicForm!: FormGroup;
  res:any;

  constructor(private fb: FormBuilder, private toastController: ToastController, private convertservice: ConvertService) { 
    this.dynamicForm = this.fb.group({
      firstnum: ['', Validators.required],
      numbers: ['', [this.numberRangeValidator]],
    });
  }

  ras(){
    this.res = this.convertservice.convertToBase(this.dynamicForm.get('firstnum')?.value, this.dynamicForm.get('numbers')?.value)
  }

  numberRangeValidator(control: AbstractControl) {
    const value = control.value;
    if (Validators.required(control) !== null) {
      return false;
    }
    if (isNaN(value) || value < 2 || value > 16) {
      return false;
    }
    else{
      return true;
    }

  }

  async presentErrorToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
      position: 'top',
      color: 'danger'
    });
    toast.present();
  }

  onSubmit(){
    if (this.dynamicForm.get('numbers')?.value >= 2 && this.dynamicForm.get('numbers')?.value<=16){
      console.log("Submit")
    }
    else{
      this.presentErrorToast('Число поза діапазоном')
    }
  }

  ngOnInit() {}

}


