import { TestBed } from '@angular/core/testing';

import { ConvertService } from './convert.service';

describe('ConvertService', () => {
  let service: ConvertService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConvertService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  fit('Перевод 3 у двоїчну систему', ()=>{
    let x = 3;
    let y = '11';
    let res = service.convertToBase(x,2)
    expect(res == '11')
  })
});
