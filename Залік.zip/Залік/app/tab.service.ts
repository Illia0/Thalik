import { Injectable,Optional } from '@angular/core';
import { LogService } from './log.service';

@Injectable({
  providedIn: 'root'
})
export class TabService {
  private xy=new Map();

  constructor(@Optional() private logService : LogService) {}
  getTab(xn:number=-3.14, xk:number=3.14,h:number=0.1):Map<number,number>{
    let x = xn,
    y = 3.14/2;
    let n = 1;
    while(x<=xk){
      y = y - 4/3.14*Math.cos(n*x)/(n*n);
      this.xy.set(x,y)
      if(this.logService){
        this.logService.write("x="+x.toFixed(2)+" y="+y.toFixed(4));
      }
      n  = n + 2;
      x=x+h;
    }
    return this.xy
  }
}
