import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-thalik-header',
  templateUrl: './thalik-header.component.html',
  styleUrls: ['./thalik-header.component.scss'],
})
export class ThalikHeaderComponent implements OnInit {
  @Input() name: string="Залікова робота"


  constructor() { 
  }

  ngOnInit() {
  }

}
