import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ThalikPageRoutingModule } from './thalik-routing.module';

import { ThalikPage } from './thalik.page';
import { ThalikHeaderComponent } from '../thalik-header/thalik-header.component'
import { ThalikFormsComponent } from '../thalik-forms/thalik-forms.component'
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ThalikPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [ThalikPage, ThalikHeaderComponent, ThalikFormsComponent]
})
export class ThalikPageModule {}
