import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thalik',
  templateUrl: './thalik.page.html',
  styleUrls: ['./thalik.page.scss'],
})
export class ThalikPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
