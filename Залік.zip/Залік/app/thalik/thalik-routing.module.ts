import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ThalikPage } from './thalik.page';

const routes: Routes = [
  {
    path: '',
    component: ThalikPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ThalikPageRoutingModule {}
