import { Component, OnInit } from '@angular/core';
import { TabService } from '../tab.service';

@Component({
  selector: 'app-lab7',
  templateUrl: './lab7.page.html',
  styleUrls: ['./lab7.page.scss'],
})
export class Lab7Page implements OnInit {

  constructor(private tabService:TabService) { }
  xyTab=new Map();
  xyInput = new Map();
  ras(xn:any,xk:any,h:any){
    let xn1=parseFloat(xn),
    xk1 = parseFloat(xk),
    h1 = parseFloat(h);
    console.log("Табулювання");
    this.xyTab = this.tabService.getTab(xn1,xk1,h1);
    this.Input()
  }

  Input(){
    this.xyTab.forEach((value,key,map)=>{
      let s = '';
      let y:number = 0;
      y=value;
      s=y.toFixed(4)+" ";
      y=this.xyTab.get(key);
      let x = key;
      this.xyInput.set(x.toFixed(2),s)
    }
    
    )
  }


  ngOnInit() {
  }

}
